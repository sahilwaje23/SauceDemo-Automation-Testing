"""Create a standalone performance HTML summary from aggregate.csv."""
import csv
from datetime import date
from html import escape
from pathlib import Path

ROOT = Path(__file__).resolve().parent
with (ROOT / "results/aggregate.csv").open(newline="", encoding="utf-8-sig") as stream:
    rows = list(csv.DictReader(stream))
by_label = {row["label"]: row for row in rows}


def p95(label):
    return int(by_label[label]["p95_ms"])


def errors(label):
    return float(by_label[label]["error_percent"])


login = "Login page document (GET /)"
products = "Products app shell (GET / with session cookie)"
total_samples = sum(int(row["samples"]) for row in rows)
total_errors = sum(int(row["errors"]) for row in rows)
overall_error_rate = total_errors / total_samples * 100 if total_samples else 0
nfrs = [
    ("NFR-01", "Login document P95", p95(login), 3000, "ms", "PASS" if p95(login) < 3000 else "FAIL"),
    ("NFR-02", "Authenticated app shell P95", p95(products), 4000, "ms", "PASS" if p95(products) < 4000 else "FAIL"),
    ("NFR-03", "Overall error rate", overall_error_rate, 2, "%", "PASS" if overall_error_rate < 2 else "FAIL"),
]
metric_rows = "".join(
    f"<tr><td>{escape(nfr)}</td><td>{escape(metric)}</td><td>{value:.0f}{unit if unit == '%' else ' '+unit}</td>"
    f"<td>&lt; {limit}{unit if unit == '%' else ' '+unit}</td><td class='{status.lower()}'>{status}</td></tr>"
    for nfr, metric, value, limit, unit, status in nfrs
)
resource_labels = ["Application JavaScript bundle", "Application CSS bundle"]
resource_rows = "".join(
    f"<tr><td>{escape(label)}</td><td>{int(by_label[label]['samples'])}</td>"
    f"<td>{int(by_label[label]['p95_ms']):,} ms</td><td>{float(by_label[label]['error_percent']):.3f}%</td></tr>"
    for label in resource_labels if label in by_label
)
html = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>SauceDemo Performance Report</title>
<style>
body{{margin:0;background:#f4f7fb;color:#172334;font:15px/1.5 'Segoe UI',Arial,sans-serif}}main{{max-width:1050px;margin:42px auto;padding:0 22px}}.eyebrow{{color:#64748b;font-size:11px;letter-spacing:.12em;font-weight:700}}h1{{font-size:31px;margin:0}}.sub{{color:#64748b;margin:8px 0 25px}}.summary{{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin:20px 0 30px}}.card{{background:white;border:1px solid #e2e8f0;border-radius:14px;padding:19px;box-shadow:0 4px 16px #2538580a}}.card span{{color:#64748b;font-size:13px}}.card strong{{display:block;font-size:26px;margin-top:3px}}h2{{font-size:18px;margin:30px 0 12px}}table{{width:100%;border-collapse:collapse;background:#fff;border-radius:12px;overflow:hidden}}td,th{{text-align:left;padding:12px 14px;border-bottom:1px solid #e9edf2}}th{{background:#eef2f7;color:#475467;font-size:12px}}.pass{{color:#13805c;font-weight:700}}.fail{{color:#bd3c49;font-weight:700}}.note{{margin-top:22px;padding:14px 16px;background:#eff4ff;border:1px solid #d8e3ff;border-radius:10px;color:#334776;font-size:13px}}footer{{margin-top:22px;color:#64748b;font-size:12px}}@media(max-width:700px){{main{{overflow-x:auto}}table{{min-width:650px}}.summary{{grid-template-columns:1fr}}}}
</style></head><body><main>
<p class="eyebrow">SAUCEDEMO · JMETER PERFORMANCE</p><h1>Performance report</h1>
<p class="sub">Recorded run: November 5, 2026 · Apache JMeter 5.6.3 · 20 users · 60-second ramp · 180 seconds</p>
<section class="summary"><div class="card"><span>Total HTTP samples</span><strong>{total_samples:,}</strong></div><div class="card"><span>Errors</span><strong>{total_errors} ({overall_error_rate:.3f}%)</strong></div><div class="card"><span>Load profile</span><strong>20 users</strong></div></section>
<h2>NFR threshold results</h2><table><thead><tr><th>Requirement</th><th>Metric</th><th>Measured</th><th>Threshold</th><th>Result</th></tr></thead><tbody>{metric_rows}</tbody></table>
<h2>Application resources</h2><table><thead><tr><th>Sampler</th><th>Samples</th><th>P95</th><th>Error rate</th></tr></thead><tbody>{resource_rows}</tbody></table>
<div class="note"><strong>Measurement scope:</strong> The login and authenticated product route samples measure HTTP app-shell responses. SauceDemo performs login and React routing in client-side JavaScript, which JMeter does not execute. These figures do not include browser rendering or end-to-end UI timing.</div>
<footer>Generated from <code>performance/results/aggregate.csv</code>. To collect a new run and create the native JMeter dashboard, run <code>performance/run_jmeter.ps1</code>.</footer>
</main></body></html>"""
destination = ROOT / "html_report/index.html"
destination.parent.mkdir(parents=True, exist_ok=True)
destination.write_text(html, encoding="utf-8")
print(f"Generated performance report: {destination}")
