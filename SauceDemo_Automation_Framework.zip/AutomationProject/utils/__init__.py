"""Framework utilities."""
