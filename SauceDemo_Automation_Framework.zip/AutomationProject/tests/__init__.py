"""Functional automation tests."""
